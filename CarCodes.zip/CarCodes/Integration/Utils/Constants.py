class Constants:
    use_devices = True

    # Balloon alignments
    b_friendly = 1
    b_hostile = 2
    b_unknown = 3
